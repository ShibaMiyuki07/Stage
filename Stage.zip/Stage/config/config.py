import pymongo


def connexion_base():
    client = pymongo.MongoClient("mongodb://oma_dwh:Dwh4%40OrnZ@192.168.61.199:27017/?authMechanism=DEFAULT")
    return client


def getcollection_config():
    client = connexion_base()
    db = client['test']
    collection = db['dashboard_config']
    return collection

if __name__ == "__main__":
    a_inserez = []
    i= 1
    getcollection_config().delete_many({})
    usage_type = ['usage','bundle','topup','om','ec','e-rc','roaming','parc','nomad']


    config = {}
    config['usage'] = ['voice_o_amnt','sms_o_amnt','data_amnt','voice_vas_amnt','sms_vas_amnt']
    config['bundle'] = ['bndle_amnt','bndl_cnt']
    config['topup'] = ['rec_cnt','rec_amnt']
    config['om'] = ['om_cnt','om_tr_amnt','om_amnt']
    config['ec'] = ['ec_qty','ec_loan']
    config['e-rc'] = ['nb']
    config['roaming'] = ['voice_o_cnt']
    config['parc'] = ['parc_FT','parc_rec_1j']
    config['nomad']= ['nb']

    for u in usage_type:
        nom = []
        for c in config[u]:
            nom.append({'nom' : c})
        a_inserez.append({'usage_type' : u,'identifiant' :i,'type_donne' : 'config','colonne' : nom})
        i+=1

    getcollection_config().insert_many(a_inserez)
    



