import mysql.connector
import pymongo
from datetime import datetime

def connexion_sql():    
    connexion = mysql.connector.connect(user='ETL_USER',password='3tl_4ser',host='192.168.61.196',database="WORK")
    return connexion
    
def connexion_base():
    client = pymongo.MongoClient("mongodb://oma_dwh:Dwh4%40OrnZ@192.168.61.199:27017/?authMechanism=DEFAULT")
    return client
    
def getcollection_global():
    client =connexion_base()
    db = client['cbm']
    collection = db['global_daily_usage']
    return collection
    
    
    
def getdata_global():
  pipeline = [
    {
        '$match': {
            'usage_type': 'nomad'
        }
    }, {
        '$group': {
            '_id': '$day', 
            'nb': {
                '$sum': '$nb'
            }, 
            'nb_semaine': {
                '$sum': '$nb_semaine'
            }
        }
    }, {
        '$sort': {
            '_id': -1
        }
    }
]
  collection = getcollection_global()
  resultats = collection.aggregate(pipeline)
  retour = {}
  for r in resultats :
    retour[r['_id']] = r['nb']
    
  return retour
   
def getdata_sql():
  query = "SELECT creationDate date,COUNT(identifiant_vendeur) nb FROM ech_msisdn_capillarite_jour GROUP BY creationDate"
  con = connexion_sql()
  cursor = con.cursor() 
  cursor.execute(query)
  retour = {}
  for(date,nb) in cursor:
    date_utiliser = date.__str__().split('-')
    date_final = datetime(int(date_utiliser[0]),int(date_utiliser[1]),int(date_utiliser[2]))
    retour[date_final] = nb
  return retour
  
  
  
  
  
  
  
def verification_data():
  data_sql = getdata_sql()
  global_data = getdata_global()
  for i in global_data.keys():
    if i in data_sql and i in global_data:
      diff = global_data[i] - data_sql[i]
      if diff!=0:
        print(i.__str__()+" difference de "+diff.__str__())
      if diff ==0:
        print(i.__str__()+" egales")
        
        
        
if __name__ == "__main__":
  verification_data()