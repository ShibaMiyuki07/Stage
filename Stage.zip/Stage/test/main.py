import subprocess

if __name__ == "__main__":
  cmd = "ls"
  test = subprocess.check_output(cmd,shell=True).decode('utf-8')
  