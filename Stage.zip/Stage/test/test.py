if __name__ == "__main__":
  print('mety1')
  print('mety2')