if __name__ == "__main__":
    fichier ='log/rattra_daily_20230814.log'
    with open(fichier) as f:
        print(f.read())